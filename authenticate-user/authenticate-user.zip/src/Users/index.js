const userRouter = require('./userRouter')
module.exports = userRouter
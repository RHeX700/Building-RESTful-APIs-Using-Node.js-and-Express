const oauthrouter = require('./auth.api');

module.exports = oauthrouter;
const movieRouter = require("./movierouter");

module.exports = movieRouter;
